import React, { useState, useEffect, useRef } from 'react';

// --- MOCK DATA ---
const MOCK_DRAWINGS = [
  { id: 1, word: 'Máy bay', user: 'Bạn', emoji: '✈️', shared: false },
  { id: 2, word: 'Quả táo', user: 'Bạn', emoji: '🍎', shared: true },
  { id: 3, word: 'Ngôi nhà', user: 'Bạn', emoji: '🏠', shared: false },
  { id: 4, word: 'Con mèo', user: 'Bạn', emoji: '🐱', shared: false },
  { id: 5, word: 'Mặt trời', user: 'Bạn', emoji: '☀️', shared: true },
  { id: 6, word: 'Cái xe', user: 'Bạn', emoji: '🚗', shared: false },
];

const COMMUNITY_DRAWINGS = [
  { id: 101, word: 'Quả táo', user: 'Minh', emoji: '🍎', likes: 12 },
  { id: 102, word: 'Quả táo', user: 'Lan', emoji: '🍏', likes: 5 },
  { id: 103, word: 'Quả táo', user: 'Khoa', emoji: '🍎', likes: 8 },
  { id: 104, word: 'Quả táo', user: 'Nhi', emoji: '🍏', likes: 20 },
];

// --- MAIN APP COMPONENT ---
export default function DrawingGameApp() {
  const [currentScreen, setCurrentScreen] = useState('home');
  const [selectedDrawing, setSelectedDrawing] = useState<any>(null);
  const [currentRound, setCurrentRound] = useState(0);
  const [hintsLeft, setHintsLeft] = useState(3);

  const handleStartGame = () => {
    setCurrentRound(0);
    setHintsLeft(3);
    setCurrentScreen('ready');
  };

  const handleNextRound = () => {
    if (currentRound < MOCK_DRAWINGS.length - 1) {
      setCurrentRound(prev => prev + 1);
      setCurrentScreen('ready');
    } else {
      setCurrentScreen('summary');
    }
  };

  const currentWordObj = MOCK_DRAWINGS[currentRound] || MOCK_DRAWINGS[0];

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home': return <HomeScreen setScreen={setCurrentScreen} onStart={handleStartGame} />;
      case 'ready': return <ReadyScreen setScreen={setCurrentScreen} currentWord={currentWordObj} />;
      case 'game': return <GameScreen setScreen={setCurrentScreen} currentWord={currentWordObj} onNextRound={handleNextRound} hintsLeft={hintsLeft} setHintsLeft={setHintsLeft} />;
      case 'summary': return <SummaryScreen setScreen={setCurrentScreen} setSelectedDrawing={setSelectedDrawing} />;
      case 'detail': return <DetailScreen setScreen={setCurrentScreen} drawing={selectedDrawing} />;
      case 'community': return <CommunityScreen setScreen={setCurrentScreen} />;
      default: return <HomeScreen setScreen={setCurrentScreen} onStart={handleStartGame} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-0 md:p-4 font-sans text-gray-900 select-none">
      {/* Khung viền iPad giả lập trên desktop, full màn hình trên mobile */}
      <div className="w-full max-w-5xl h-[100dvh] md:h-[80vh] md:min-h-[750px] bg-white md:rounded-[3rem] md:shadow-[12px_12px_0px_0px_rgba(31,41,55,1)] md:border-[10px] border-gray-800 overflow-hidden relative flex flex-col">
        {renderScreen()}
      </div>
    </div>
  );
}

// --- SCREEN 1: HOME SCREEN (Có Background Custom) ---
function HomeScreen({ setScreen, onStart }: any) {
  return (
    <div 
      className="h-full w-full relative flex flex-col items-center justify-between py-12 px-8 bg-sky-200"
      style={{
        backgroundImage: "url('https://images.unsplash.com/photo-1560421683-6856ea585c78?q=80&w=2074&auto=format&fit=crop')", // Placeholder image
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {/* Lớp phủ nhẹ nếu ảnh nền quá chói */}
      <div className="absolute inset-0 bg-white/40 pointer-events-none"></div>

      {/* Tiêu đề trò chơi */}
      <div className="z-10 mt-10 md:mt-4 relative px-4 text-center">
        <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-wider" 
            style={{ WebkitTextStroke: '4px #1f2937', textShadow: '6px 6px 0px #1f2937' }}>
          Cuộc Phiêu Lưu
        </h1>
        <h1 className="text-4xl md:text-6xl font-black text-yellow-300 uppercase tracking-wider mt-2"
            style={{ WebkitTextStroke: '4px #1f2937', textShadow: '6px 6px 0px #1f2937' }}>
          Vẽ Của Artie
        </h1>
      </div>

      {/* Robot Character (Dự phòng nếu ảnh nền không có robot) */}
      <div 
        className="z-10 absolute top-[50%] md:top-[60%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-[140px] md:text-[200px] animate-bounce" 
        style={{ animationDuration: '3s' }}
      >
        🤖
      </div>

      {/* Khu vực nút bấm nằm ở dưới cùng */}
      <div className="z-10 flex flex-col md:flex-row gap-4 md:gap-6 mb-8 mt-auto relative w-full md:w-auto px-4 md:px-0">
        <button 
          onClick={onStart}
          className="bg-cyan-300 hover:bg-cyan-200 text-2xl md:text-3xl font-black py-4 px-6 md:px-10 rounded-full border-4 border-gray-800 shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] transition-transform active:translate-y-2 active:shadow-none flex items-center justify-center gap-3 w-full md:w-auto"
        >
          ✏️ Cùng Vẽ Nào!
        </button>

        <button 
          onClick={() => setScreen('community')}
          className="bg-yellow-400 hover:bg-yellow-300 text-xl md:text-2xl font-black py-4 px-6 md:px-8 rounded-full border-4 border-gray-800 shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] transition-transform active:translate-y-2 active:shadow-none flex items-center justify-center gap-3 w-full md:w-auto"
        >
          🌍 Cộng Đồng
        </button>
      </div>
    </div>
  );
}

// --- SCREEN 2: READY SCREEN ---
function ReadyScreen({ setScreen, currentWord }: any) {
  return (
    <div className="h-full w-full bg-sky-300 flex flex-col items-center justify-center relative p-4">
      <div className="bg-white px-8 py-10 md:px-16 md:py-12 rounded-3xl md:rounded-[3rem] border-4 md:border-8 border-gray-800 shadow-[8px_8px_0px_0px_rgba(31,41,55,1)] md:shadow-[12px_12px_0px_0px_rgba(31,41,55,1)] flex flex-col items-center transform -rotate-2 w-full max-w-lg text-center">
        <h2 className="text-2xl md:text-4xl font-bold mb-4 md:mb-6 text-gray-700">Từ khóa của bé là:</h2>
        <h1 className="text-5xl md:text-7xl font-black mb-8 md:mb-12 text-blue-500 uppercase truncate w-full px-2"
            style={{ WebkitTextStroke: '3px #1f2937', textShadow: '4px 4px 0px #1f2937' }}>
          {currentWord?.word}
        </h1>
        <button 
          onClick={() => setScreen('game')}
          className="bg-yellow-400 text-gray-900 text-2xl md:text-4xl font-black py-4 px-10 md:py-5 md:px-16 rounded-full border-4 border-gray-800 shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] md:shadow-[8px_8px_0px_0px_rgba(31,41,55,1)] active:translate-y-2 active:shadow-none transition-all hover:bg-yellow-300 animate-bounce w-full md:w-auto"
        >
          SẴN SÀNG!
        </button>
      </div>
    </div>
  );
}

// --- SCREEN 3: GAMEPLAY SCREEN ---
function GameScreen({ setScreen, currentWord, onNextRound, hintsLeft, setHintsLeft }: any) {
  const [aiGuess, setAiGuess] = useState("AI đang xem bé vẽ...");
  const [showHint, setShowHint] = useState(false);
  const [timeLeft, setTimeLeft] = useState(20);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  
  const handleShowHint = () => {
    if (hintsLeft > 0 && !showHint) {
      setHintsLeft((prev: number) => prev - 1);
      setShowHint(true);
      setTimeout(() => setShowHint(false), 3000);
    }
  };

  useEffect(() => {
    setTimeLeft(20);
    const timer = setInterval(() => {
      setTimeLeft(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);
    return () => clearInterval(timer);
  }, [currentWord]);

  useEffect(() => {
    if (timeLeft === 0) {
      onNextRound();
    }
  }, [timeLeft, onNextRound]);

  useEffect(() => {
    const guesses = ["Hình như là đường thẳng...", "Có phải là hình tròn?", `Đó là ${currentWord?.word?.toUpperCase()}!`];
    let i = 0;
    const interval = setInterval(() => {
      setAiGuess(guesses[i]);
      i++;
      if (i >= guesses.length) {
        clearInterval(interval);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [currentWord]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas && canvas.parentElement) {
      canvas.width = canvas.parentElement.clientWidth;
      canvas.height = canvas.parentElement.clientHeight;
    }
  }, []);

  const startDrawing = (e: any) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: any) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;

    ctx.lineTo(x, y);
    ctx.strokeStyle = '#1f2937';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  return (
    <div className="h-full w-full bg-emerald-200 p-4 md:p-8 flex flex-col relative">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 md:mb-6 z-10 gap-4">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <button onClick={() => setScreen('home')} className="w-12 h-12 md:w-14 md:h-14 bg-white border-4 border-gray-800 rounded-full flex justify-center items-center text-xl md:text-2xl font-bold shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] hover:bg-gray-100 active:translate-y-1 active:shadow-none shrink-0">⬅</button>
          <h2 className="text-2xl md:text-4xl font-black bg-white px-4 md:px-8 py-2 md:py-3 rounded-full border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] md:shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] text-blue-600 flex-1 text-center md:text-left truncate">
            Vẽ: {currentWord?.word?.toUpperCase()}
          </h2>
        </div>
        <div className="flex items-center gap-2 md:gap-4 w-full md:w-auto justify-between md:justify-end">
          <div className="bg-white px-4 md:px-6 py-2 md:py-3 rounded-full border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] text-xl md:text-2xl font-black flex items-center gap-2">
            ⏱️ {timeLeft}s
          </div>
          {/* Nút cứu trợ chuyển lên trên */}
          <button 
            onClick={handleShowHint}
            disabled={hintsLeft === 0 || showHint}
            className={`${hintsLeft === 0 || showHint ? 'bg-gray-400 opacity-80' : 'bg-yellow-400 hover:bg-yellow-300 active:translate-y-1'} text-lg md:text-xl font-black py-2 md:py-3 px-4 md:px-6 rounded-full border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] active:shadow-none flex items-center gap-2 transition-all`}
          >
            💡 Cứu trợ {hintsLeft > 0 && `(${hintsLeft})`}
          </button>
        </div>
      </div>

      <div className="flex-1 bg-white rounded-2xl md:rounded-[2rem] border-4 border-gray-800 shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] md:shadow-[8px_8px_0px_0px_rgba(31,41,55,1)] relative flex flex-col items-center justify-center overflow-hidden touch-none">
        <canvas 
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="absolute inset-0 w-full h-full cursor-crosshair"
        />
        
        {/* Popup Hint */}
        {showHint && (
          <div className="absolute top-4 right-4 bg-white border-4 border-gray-800 rounded-2xl p-4 md:p-6 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] md:shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] z-20 flex flex-col items-center animate-bounce">
            <span className="text-6xl md:text-[100px] leading-none mb-2">{currentWord?.emoji}</span>
            <span className="font-black text-gray-700 text-lg md:text-xl uppercase">{currentWord?.word}</span>
          </div>
        )}
      </div>

      {/* Bong bóng chat của AI nằm phía dưới khung vẽ */}
      <div className="flex justify-center items-end gap-2 md:gap-6 mt-4 md:mt-6 h-20 md:h-24 shrink-0">
        <div className="text-5xl md:text-7xl animate-pulse pb-2 md:pb-0">🤖</div>
        <div className="bg-blue-500 text-white font-bold text-lg md:text-2xl px-4 md:px-8 py-3 md:py-4 rounded-3xl rounded-tl-none border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] md:shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] mb-4 w-full max-w-sm text-center">
          {aiGuess}
        </div>
      </div>
    </div>
  );
}

// --- SCREEN 4: SUMMARY SCREEN ---
function SummaryScreen({ setScreen, setSelectedDrawing }: any) {
  const [sharePopup, setSharePopup] = useState(false);

  const handleShare = (e: any) => {
    e.stopPropagation();
    setSharePopup(true);
  };

  return (
    <div className="h-full w-full bg-sky-200 p-4 md:p-8 flex flex-col relative overflow-y-auto">
      <div className="flex justify-between items-center mb-4 md:mb-6 shrink-0 gap-4">
        <button onClick={() => setScreen('home')} className="w-10 h-10 md:w-12 md:h-12 bg-white border-4 border-gray-800 rounded-full text-lg md:text-xl font-bold shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] flex items-center justify-center hover:bg-gray-100 active:translate-y-1 active:shadow-none transition-all shrink-0">⬅</button>
        <h1 className="flex-1 text-2xl md:text-4xl font-black text-gray-800 uppercase tracking-wide text-center truncate">Tóm tắt thư viện</h1>
        <div className="w-10 h-10 md:w-12 md:h-12 shrink-0"></div>
      </div>

      <h2 className="text-3xl md:text-5xl font-black text-center mb-6 md:mb-8 text-white uppercase drop-shadow-[4px_4px_0px_rgba(31,41,55,1)]" style={{ WebkitTextStroke: '2px #1f2937' }}>
        Nghệ sĩ tuyệt vời!
      </h2>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6 flex-1 px-2 md:px-4 pb-8">
        {MOCK_DRAWINGS.map((item) => (
          <div key={item.id} className="bg-white rounded-2xl md:rounded-3xl border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] md:shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] p-3 md:p-4 flex flex-col hover:-translate-y-1 transition-transform">
            <div 
              className="flex-1 min-h-[100px] md:min-h-[140px] border-4 border-gray-200 rounded-xl md:rounded-2xl flex items-center justify-center text-5xl md:text-7xl cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => { setSelectedDrawing(item); setScreen('detail'); }}
            >
              {item.emoji}
            </div>
            <div className="mt-2 md:mt-3 text-center">
              <span className="font-bold text-sm md:text-lg truncate block">{item.word} của bạn</span>
              <button 
                onClick={handleShare}
                className="mt-2 bg-yellow-400 hover:bg-yellow-300 text-xs md:text-sm font-black py-1.5 md:py-2 px-4 md:px-6 rounded-full border-2 border-gray-800 mx-auto block transition-transform active:translate-y-1 shadow-[2px_2px_0px_0px_rgba(31,41,55,1)] uppercase"
              >
                Chia sẻ
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Share Popup */}
      {sharePopup && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 rounded-[3rem]">
           <div className="bg-white border-4 border-gray-800 rounded-3xl p-8 shadow-[8px_8px_0px_0px_rgba(31,41,55,1)] text-center flex flex-col items-center max-w-md transform scale-100 transition-transform animate-bounce" style={{ animationIterationCount: 1 }}>
             <span className="text-6xl mb-4">🌟</span>
             <h3 className="text-3xl font-black text-blue-500 mb-2 leading-tight">Bé vẽ rất đẹp!</h3>
             <p className="text-lg font-bold text-gray-600 mb-6">Tác phẩm đã được chia sẻ lên Cộng Đồng để mọi người cùng xem nhé!</p>
             <button 
               onClick={() => setSharePopup(false)}
               className="bg-yellow-400 text-xl font-black py-3 px-8 rounded-full border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] hover:bg-yellow-300 active:translate-y-1 transition-all"
             >
               Tuyệt vời!
             </button>
           </div>
        </div>
      )}
    </div>
  );
}

// --- SCREEN 5: DETAIL SCREEN ---
function DetailScreen({ setScreen, drawing }: any) {
  const [isLiked, setIsLiked] = useState(false);
  const [showShareMsg, setShowShareMsg] = useState(false);
  const [showPhotobooth, setShowPhotobooth] = useState(false);
  const [likedCommunityItems, setLikedCommunityItems] = useState<Record<number, boolean>>({});

  if (!drawing) return null;

  const handleShare = () => {
    setShowPhotobooth(true);
  };
  
  const toggleCommunityLike = (e: any, id: number) => {
    e.stopPropagation();
    setLikedCommunityItems(prev => ({...prev, [id]: !prev[id]}));
  };

  return (
    <div className="h-full w-full bg-cyan-100 p-4 md:p-8 flex flex-col relative overflow-y-auto">
      <div className="flex items-center mb-4 md:mb-8 shrink-0 gap-4">
        <button onClick={() => setScreen('summary')} className="w-10 h-10 md:w-12 md:h-12 bg-white border-4 border-gray-800 rounded-full font-bold shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] flex items-center justify-center text-lg md:text-xl hover:bg-gray-100 active:translate-y-1 active:shadow-none transition-all shrink-0">⬅</button>
        <h1 className="flex-1 text-center text-xl md:text-3xl font-black uppercase text-gray-800 truncate">Chi tiết cộng đồng</h1>
        <div className="w-10 md:w-12 shrink-0"></div>
      </div>

      <div className="flex-1 bg-white rounded-2xl md:rounded-[3rem] border-4 border-gray-800 shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] md:shadow-[8px_8px_0px_0px_rgba(31,41,55,1)] p-4 md:p-8 flex flex-col items-center relative mb-6 md:mb-8 min-h-[250px]">
        <div className="w-full flex flex-col sm:flex-row justify-between items-center sm:items-start gap-4 mb-4 md:mb-6">
          <div className="flex items-center gap-2 md:gap-3">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-orange-300 rounded-full border-4 border-gray-800 flex items-center justify-center text-xl md:text-2xl">😊</div>
            <span className="font-bold text-lg md:text-xl">{drawing.word} của Bạn</span>
          </div>
          <div className="flex gap-2 md:gap-4 relative w-full sm:w-auto justify-center">
            <button 
              onClick={() => setIsLiked(!isLiked)}
              className={`${isLiked ? 'bg-pink-400 text-white' : 'bg-sky-200'} font-bold px-3 py-1.5 md:px-5 md:py-2 text-sm md:text-base rounded-full border-4 border-gray-800 flex items-center gap-2 shadow-[2px_2px_0px_0px_rgba(31,41,55,1)] active:translate-y-1 transition-colors`}
            >
              {isLiked ? '❤️ Đã thích' : '🤍 Thích'}
            </button>
            <button 
              onClick={handleShare}
              className="bg-green-300 hover:bg-green-400 font-bold px-3 py-1.5 md:px-5 md:py-2 text-sm md:text-base rounded-full border-4 border-gray-800 flex items-center gap-2 shadow-[2px_2px_0px_0px_rgba(31,41,55,1)] active:translate-y-1 transition-colors"
            >
              🔗 Chia sẻ
            </button>
          </div>
        </div>

        <div className="flex-1 flex items-center justify-center text-[100px] sm:text-[140px] md:text-[200px] hover:scale-110 transition-transform cursor-pointer">
          {drawing.emoji}
        </div>
      </div>

      <div className="bg-white rounded-2xl md:rounded-[2rem] border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] md:shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] p-3 md:p-4 shrink-0">
        <h3 className="font-black text-center mb-2 md:mb-4 uppercase text-gray-700 text-sm md:text-base">Bản vẽ của các bạn khác</h3>
        <div className="flex gap-3 md:gap-4 overflow-x-auto pb-2">
          {COMMUNITY_DRAWINGS.map(comm => (
            <div key={comm.id} className="min-w-[100px] h-[100px] md:min-w-[120px] md:h-[120px] bg-sky-50 rounded-xl md:rounded-2xl border-4 border-gray-800 flex flex-col items-center justify-center p-2 shadow-[2px_2px_0px_0px_rgba(31,41,55,1)] cursor-pointer hover:-translate-y-1 transition-transform relative">
              <button 
                onClick={(e) => toggleCommunityLike(e, comm.id)}
                className="absolute top-1 right-1 md:top-2 md:right-2 text-lg md:text-xl z-10 active:scale-90 transition-transform"
              >
                {likedCommunityItems[comm.id] ? '❤️' : '🤍'}
              </button>
              <span className="text-4xl md:text-5xl mb-1 md:mb-2">{comm.emoji}</span>
              <span className="text-[10px] md:text-xs font-bold text-center leading-tight truncate w-full px-1">{comm.word} của {comm.user}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Photobooth Popup */}
      {showPhotobooth && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 md:rounded-[3rem] p-4">
          <div className="bg-white border-[8px] md:border-[12px] border-yellow-300 rounded-2xl p-4 md:p-6 shadow-[8px_8px_0px_0px_rgba(31,41,55,1)] md:shadow-[12px_12px_0px_0px_rgba(31,41,55,1)] flex flex-col items-center max-w-sm w-full transform scale-100 transition-transform animate-bounce relative" style={{ animationIterationCount: 1 }}>
            
            {/* Khung ảnh photobooth */}
            <div className="bg-sky-100 border-4 border-gray-800 rounded-xl w-full aspect-square flex flex-col items-center justify-center mb-4 md:mb-6 overflow-hidden relative shadow-inner">
               <div className="text-[120px] md:text-[150px] transform hover:scale-110 transition-transform">
                 {drawing.emoji}
               </div>
               {/* Decor elements */}
               <span className="absolute top-2 left-2 text-2xl md:text-3xl">✨</span>
               <span className="absolute bottom-2 right-2 text-2xl md:text-3xl">🎉</span>
            </div>

            <div className="text-center w-full">
              <h3 className="text-2xl md:text-3xl font-black text-gray-800 uppercase mb-1 md:mb-2" style={{ WebkitTextStroke: '1px white' }}>{drawing.word}</h3>
              <p className="font-bold text-gray-500 mb-4 md:mb-6 text-base md:text-lg">Tác phẩm của Bạn</p>
            </div>

            <div className="flex gap-2 md:gap-4 w-full">
               <button 
                 onClick={() => {
                   setShowShareMsg(true);
                   setTimeout(() => setShowShareMsg(false), 2000);
                 }}
                 className="flex-1 bg-green-400 hover:bg-green-300 text-base md:text-lg font-black py-2 md:py-3 rounded-full border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] active:translate-y-1 transition-all"
               >
                 Tải Xuống 📥
               </button>
               <button 
                 onClick={() => setShowPhotobooth(false)}
                 className="bg-red-400 text-white hover:bg-red-300 text-base md:text-lg font-black py-2 md:py-3 px-4 md:px-6 rounded-full border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] active:translate-y-1 transition-all"
               >
                 Đóng
               </button>
            </div>

             {showShareMsg && (
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white border-4 border-gray-800 rounded-xl px-3 py-1.5 md:px-4 md:py-2 font-bold shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] animate-bounce text-green-600 z-10 whitespace-nowrap text-sm md:text-base">
                  Đã tải xuống thành công! 🎉
                </div>
              )}
          </div>
        </div>
      )}
    </div>
  );
}

// --- SCREEN 6: COMMUNITY SCREEN ---
function CommunityScreen({ setScreen }: any) {
  const [likedItems, setLikedItems] = useState<Record<number, boolean>>({});

  const toggleLike = (idx: number) => {
    setLikedItems(prev => ({...prev, [idx]: !prev[idx]}));
  };

  return (
    <div className="h-full w-full bg-sky-100 p-4 md:p-8 flex flex-col relative overflow-y-auto">
      <div className="flex items-center mb-4 md:mb-8 shrink-0 gap-4">
        <button onClick={() => setScreen('home')} className="w-10 h-10 md:w-12 md:h-12 bg-white border-4 border-gray-800 rounded-full font-bold shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] flex items-center justify-center text-lg md:text-xl hover:bg-gray-100 active:translate-y-1 active:shadow-none transition-all shrink-0">⬅</button>
        <h1 className="flex-1 text-center text-2xl md:text-4xl font-black uppercase text-gray-800 truncate">Cộng đồng Artie</h1>
        <div className="w-10 md:w-12 shrink-0"></div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 overflow-y-auto pb-8 px-2 flex-1">
        {[...COMMUNITY_DRAWINGS, ...COMMUNITY_DRAWINGS].map((item, idx) => (
          <div key={idx} className="bg-white rounded-2xl md:rounded-3xl border-4 border-gray-800 shadow-[4px_4px_0px_0px_rgba(31,41,55,1)] md:shadow-[6px_6px_0px_0px_rgba(31,41,55,1)] p-3 md:p-4 flex flex-col hover:-translate-y-1 transition-transform">
            <div className="flex-1 h-24 md:h-32 border-4 border-gray-200 rounded-xl md:rounded-2xl flex items-center justify-center text-5xl md:text-6xl mb-2 md:mb-3 bg-gray-50 cursor-pointer">
              {item.emoji}
            </div>
            <div className="flex justify-between items-end gap-2">
              <div className="leading-tight flex-1 truncate">
                <span className="font-black text-xs md:text-sm text-gray-600 block truncate">{item.word}</span>
                <span className="font-bold text-xs md:text-sm truncate block">của {item.user}</span>
              </div>
              <button 
                onClick={() => toggleLike(idx)}
                className={`text-2xl md:text-3xl hover:scale-125 active:scale-95 transition-all shrink-0 ${likedItems[idx] ? 'text-red-500 drop-shadow-[0_2px_0_rgba(0,0,0,1)]' : 'grayscale opacity-40'}`}
              >
                ❤️
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
